---
title: Airline Sentiment Analysis
emoji: 📊
colorFrom: purple
colorTo: pink
sdk: docker
pinned: false
app_port: 8501
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
